package org.wit.videoManagement.models

import android.content.Context
import android.net.Uri
import com.google.gson.*
import com.google.gson.reflect.TypeToken
import org.wit.videoManagement.helpers.*
import timber.log.Timber
import java.lang.reflect.Type
import java.util.*

const val JSON_FILE = "Videos.json"
val gsonBuilder: Gson = GsonBuilder().setPrettyPrinting()
                 .registerTypeAdapter(Uri::class.java, UriParser())
                 .create()
val listType: Type = object : TypeToken<ArrayList<VideoModel>>() {}.type

fun generateRandomId(): Long {
    return Random().nextLong()
}

class VideoJSONStore(private val context: Context) : VideoStore {

    var Videos = mutableListOf<VideoModel>()

    init {
        if (exists(context, JSON_FILE)) {
            deserialize()
        }
    }

    override fun findAll(): MutableList<VideoModel> {
        logAll()
        return Videos
    }

    override fun create(Video: VideoModel) {
        Video.id = generateRandomId()
        Videos.add(Video)
        serialize()
    }


    override fun update(Video: VideoModel) {
        val VideosList = findAll() as ArrayList<VideoModel>
        var foundVideo: VideoModel? = VideosList.find { p -> p.id == Video.id }
        if (foundVideo != null) {
            foundVideo.channel = Video.channel
            foundVideo.videoTitle = Video.videoTitle
            foundVideo.starRating = Video.starRating
            foundVideo.tags = Video.tags
            foundVideo.image = Video.image
        }
        serialize()
    }

    override fun delete(Video: VideoModel) {
        Videos.remove(Video)
        serialize()
    }

    private fun serialize() {
        val jsonString = gsonBuilder.toJson(Videos, listType)
        write(context, JSON_FILE, jsonString)
    }

    private fun deserialize() {
        val jsonString = read(context, JSON_FILE)
        Videos = gsonBuilder.fromJson(jsonString, listType)
    }

    private fun logAll() {
        Videos.forEach { Timber.i("$it") }
    }
}

class UriParser : JsonDeserializer<Uri>,JsonSerializer<Uri> {
    override fun deserialize(
        json: JsonElement?,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): Uri {
        return Uri.parse(json?.asString)
    }

    override fun serialize(
        src: Uri?,
        typeOfSrc: Type?,
        context: JsonSerializationContext?
    ): JsonElement {
        return JsonPrimitive(src.toString())
    }
}