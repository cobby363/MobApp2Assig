package org.wit.videoManagement.models

import android.content.Context
import android.net.Uri
import com.google.gson.*
import com.google.gson.reflect.TypeToken
import org.wit.videoManagement.helpers.*
import timber.log.Timber
import java.lang.reflect.Type
import java.util.*

const val ChannelJSON_FILE = "Channels.json"
val ChannelgsonBuilder: Gson = GsonBuilder().setPrettyPrinting()
    .registerTypeAdapter(Uri::class.java, ChannelUriParser())
    .create()
val ChannellistType: Type = object : TypeToken<ArrayList<ChannelModel>>() {}.type

fun generateChannelRandomId(): Long {
    return Random().nextLong()
}

class ChannelJSONStore(private val context: Context) : ChannelStore {

    var channels = mutableListOf<ChannelModel>()

    init {
        if (exists(context, ChannelJSON_FILE)) {
            deserialize()
        }
    }

    override fun findAll(): MutableList<ChannelModel> {
        logAll()
        return channels
    }

    override fun create(channel: ChannelModel) {
        channel.id = generateChannelRandomId()
        channels.add(channel)
        serialize()
    }


    override fun update(channel: ChannelModel) {
        val channelsList = findAll() as ArrayList<ChannelModel>
        var foundchannel: ChannelModel? = channelsList.find { p -> p.id == channel.id }
        if (foundchannel != null) {
            foundchannel.channelName = channel.channelName
            foundchannel.channelLogo = channel.channelLogo
        }
        serialize()
    }

    override fun delete(channel: ChannelModel) {
        channels.remove(channel)
        serialize()
    }

    private fun serialize() {
        val jsonString = ChannelgsonBuilder.toJson(channels, ChannellistType)
        write(context, ChannelJSON_FILE, jsonString)
    }

    private fun deserialize() {
        val jsonString = read(context, ChannelJSON_FILE)
        channels = ChannelgsonBuilder.fromJson(jsonString, ChannellistType)
    }

    private fun logAll() {
        channels.forEach { Timber.i("$it") }
    }
}

class ChannelUriParser : JsonDeserializer<Uri>,JsonSerializer<Uri> {
    override fun deserialize(
        json: JsonElement?,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): Uri {
        return Uri.parse(json?.asString)
    }

    override fun serialize(
        src: Uri?,
        typeOfSrc: Type?,
        context: JsonSerializationContext?
    ): JsonElement {
        return JsonPrimitive(src.toString())
    }
}