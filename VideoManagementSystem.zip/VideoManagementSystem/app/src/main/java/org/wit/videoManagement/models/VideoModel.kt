package org.wit.videoManagement.models

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class VideoModel(var id: Long = 0,
                      var channel: String = "",
                      var videoTitle: String = "",
                      var starRating: Float = 0f,
                      var tags: ArrayList<String> = arrayListOf(),
                      var image: Uri = Uri.EMPTY) : Parcelable