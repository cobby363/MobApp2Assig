package org.wit.videoManagement.models

import timber.log.Timber.i

var lastId = 0L

internal fun getId(): Long {
    return lastId++
}

class VideoMemStore : VideoStore {

    val Videos = ArrayList<VideoModel>()

    override fun findAll(): List<VideoModel> {
        return Videos
    }

    override fun create(Video: VideoModel) {
        Video.id = getId()
        Videos.add(Video)
        logAll()
    }

    override fun update(Video: VideoModel) {
        val foundVideo: VideoModel? = Videos.find { p -> p.id == Video.id }
        if (foundVideo != null) {
            foundVideo.channel = Video.channel
            foundVideo.videoTitle = Video.videoTitle
            foundVideo.image = Video.image
            logAll()
        }
    }

    override fun delete(Video: VideoModel) {
        Videos.remove(Video)
    }

    private fun logAll() {
        Videos.forEach { i("$it") }
    }
}