package org.wit.videoManagement.activities

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import videoManagement.R

import videoManagement.databinding.ActivityChannelBinding
import org.wit.videoManagement.main.MainApp
import org.wit.videoManagement.models.ChannelModel
import org.wit.videoManagement.showImagePicker
import timber.log.Timber

class ChannelActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChannelBinding
    var Channel = ChannelModel()
    lateinit var app: MainApp
    private lateinit var imageIntentLauncher : ActivityResultLauncher<Intent>
    var edit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityChannelBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbarAdd.title = title
        setSupportActionBar(binding.toolbarAdd)

        app = application as MainApp

        Timber.i("Channel Activity started...")

        if (intent.hasExtra("Channel_edit")) {
            edit = true
            Channel = intent.extras?.getParcelable("Channel_edit")!!
            binding.channelName.setText(Channel.channelName)
            binding.channelBtnAdd.setText(R.string.save_Channel)
            Picasso.get()
                .load(Channel.channelLogo)
                .into(binding.channelLogo)
            if (Channel.channelLogo != Uri.EMPTY) {
                binding.chooseImage.setText(R.string.change_Channel_image)
            }
        }

        binding.channelBtnAdd.setOnClickListener() {
            Channel.channelName = binding.channelName.text.toString()
            if (Channel.channelName.isEmpty()) {
                Snackbar.make(it, R.string.enter_Channel_name, Snackbar.LENGTH_LONG)
                    .show()
            } else {
                if (edit) {
                    app.Channels.update(Channel.copy())
                } else {
                    app.Channels.create(Channel.copy())
                }
            }
            Timber.i("add Button Pressed: $Channel")
            setResult(RESULT_OK)
            finish()
        }

        binding.chooseImage.setOnClickListener {
            showImagePicker(imageIntentLauncher)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_video, menu)
        if (edit) menu.getItem(0).isVisible = true
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_delete -> {
                app.Channels.delete(Channel)
                finish()
            }
            R.id.item_cancel -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun registerImagePickerCallback() {
        imageIntentLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult())
            { result ->
                when(result.resultCode){
                    RESULT_OK -> {
                        if (result.data != null) {
                            Timber.i("Got Result ${result.data!!.data}")
                            Channel.channelLogo = result.data!!.data!!
                            Picasso.get()
                                .load(Channel.channelLogo)
                                .into(binding.channelLogo)
                            binding.chooseImage.setText(R.string.change_Channel_image)
                        } // end of if
                    }
                    RESULT_CANCELED -> { } else -> { }
                }
            }
    }
}