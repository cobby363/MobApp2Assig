package org.wit.videoManagement.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.widget.RatingBar
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import videoManagement.R

import videoManagement.databinding.ActivityVideoBinding
import org.wit.videoManagement.main.MainApp
import org.wit.videoManagement.models.VideoModel
import org.wit.videoManagement.showImagePicker
import timber.log.Timber.i
import java.io.File
import java.io.IOException
import java.net.URI
import java.text.SimpleDateFormat
import java.util.*

class VideoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoBinding
    var Video = VideoModel()
    lateinit var app: MainApp
    private lateinit var imageIntentLauncher : ActivityResultLauncher<Intent>
    var edit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityVideoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbarAdd.title = title
        setSupportActionBar(binding.toolbarAdd)

        app = application as MainApp

        i("Video Activity started...")

        if (intent.hasExtra("Video_edit")) {
            edit = true
            Video = intent.extras?.getParcelable("Video_edit")!!
            binding.VideoTitle.setText(Video.channel)
            binding.description.setText(Video.videoTitle)
            binding.simpleRatingBar.rating = Video.starRating
            binding.btnAdd.setText(R.string.save_Video)
            Picasso.get()
                .load(Video.image)
                .into(binding.VideoImage)
            if (Video.image != Uri.EMPTY) {
                binding.chooseImage.setText(R.string.change_Video_image)
            }
        }

        binding.btnAdd.setOnClickListener() {
            Video.channel = binding.VideoTitle.text.toString()
            Video.videoTitle = binding.description.text.toString()
            Video.starRating = binding.simpleRatingBar.rating
            if (Video.channel.isEmpty()) {
                Snackbar.make(it,R.string.enter_Video_title, Snackbar.LENGTH_LONG)
                        .show()
            } else {
                if (edit) {
                    app.Videos.update(Video.copy())
                } else {
                    app.Videos.create(Video.copy())
                }
            }
            i("add Button Pressed: $Video")
            setResult(RESULT_OK)
            finish()
        }

        binding.chooseImage.setOnClickListener {
            showImagePicker(imageIntentLauncher)
        }

        binding.takeImage.setOnClickListener{
            dispatchTakePictureIntent()
        }
        registerImagePickerCallback()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_video, menu)
        if (edit) menu.getItem(0).isVisible = true
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_delete -> {
                app.Videos.delete(Video)
                finish()
            }
            R.id.item_cancel -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun registerImagePickerCallback() {
        imageIntentLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult())
            { result ->
                when(result.resultCode){
                    RESULT_OK -> {
                        if (result.data != null) {
                            i("Got Result ${result.data!!.data}")
                            Video.image = result.data!!.data!!
                            Picasso.get()
                                   .load(Video.image)
                                   .into(binding.VideoImage)
                            binding.chooseImage.setText(R.string.change_Video_image)
                        } // end of if
                    }
                    RESULT_CANCELED -> { } else -> { }
                }
            }
    }
//
    val REQUEST_IMAGE_CAPTURE = 1





    lateinit var currentPhotoPath: String

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }
    //    private fun dispatchTakePictureIntent() {
//        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//        try {
//            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
//        } catch (e: ActivityNotFoundException) {
//            // display error state to the user
//        }
//    }
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    // Error occurred while creating the File
                    null
                }
                // Continue only if the File was successfully created
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "com.example.android.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                    Video.image = photoURI
                    Picasso.get()
                        .load(Video.image)
                        .into(binding.VideoImage)
                    binding.chooseImage.setText(R.string.change_Video_image)
                }
            }
        }
    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
//            val imageBitmap = data?.extras?.get("data") as Bitmap
//            binding.VideoImage.setImageBitmap(imageBitmap)
//        }
//    }

}


private fun RatingBar.setOnRatingBarChangeListener(function: () -> Unit) {

}

