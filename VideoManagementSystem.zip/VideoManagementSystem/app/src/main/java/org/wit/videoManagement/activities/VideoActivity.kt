package org.wit.videoManagement.activities

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import videoManagement.R

import videoManagement.databinding.ActivityVideoBinding
import org.wit.videoManagement.main.MainApp
import org.wit.videoManagement.models.VideoModel
import org.wit.videoManagement.showImagePicker
import timber.log.Timber.i

class VideoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoBinding
    var Video = VideoModel()
    lateinit var app: MainApp
    private lateinit var imageIntentLauncher : ActivityResultLauncher<Intent>
    //var location = Location(52.245696, -7.139102, 15f)
    var edit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityVideoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbarAdd.title = title
        setSupportActionBar(binding.toolbarAdd)

        app = application as MainApp

        i("Video Activity started...")

        if (intent.hasExtra("Video_edit")) {
            edit = true
            Video = intent.extras?.getParcelable("Video_edit")!!
            binding.VideoTitle.setText(Video.title)
            binding.description.setText(Video.description)
            binding.btnAdd.setText(R.string.save_Video)
            Picasso.get()
                .load(Video.image)
                .into(binding.VideoImage)
            if (Video.image != Uri.EMPTY) {
                binding.chooseImage.setText(R.string.change_Video_image)
            }
        }

        binding.btnAdd.setOnClickListener() {
            Video.title = binding.VideoTitle.text.toString()
            Video.description = binding.description.text.toString()
            if (Video.title.isEmpty()) {
                Snackbar.make(it,R.string.enter_Video_title, Snackbar.LENGTH_LONG)
                        .show()
            } else {
                if (edit) {
                    app.Videos.update(Video.copy())
                } else {
                    app.Videos.create(Video.copy())
                }
            }
            i("add Button Pressed: $Video")
            setResult(RESULT_OK)
            finish()
        }

        binding.chooseImage.setOnClickListener {
            showImagePicker(imageIntentLauncher)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_video, menu)
        if (edit) menu.getItem(0).isVisible = true
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_delete -> {
                app.Videos.delete(Video)
                finish()
            }
            R.id.item_cancel -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun registerImagePickerCallback() {
        imageIntentLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult())
            { result ->
                when(result.resultCode){
                    RESULT_OK -> {
                        if (result.data != null) {
                            i("Got Result ${result.data!!.data}")
                            Video.image = result.data!!.data!!
                            Picasso.get()
                                   .load(Video.image)
                                   .into(binding.VideoImage)
                            binding.chooseImage.setText(R.string.change_Video_image)
                        } // end of if
                    }
                    RESULT_CANCELED -> { } else -> { }
                }
            }
    }
}