package org.wit.videoManagement.models

interface VideoStore {
    fun findAll(): List<VideoModel>
    fun create(Video: VideoModel)
    fun update(Video: VideoModel)
    fun delete(Video: VideoModel)
}