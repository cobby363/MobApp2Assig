package org.wit.videoManagement.models

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ChannelModel (var id: Long = 0,
                         var channelName: String = "",
                         var channelLogo: Uri = Uri.EMPTY):Parcelable