package org.wit.videoManagement.models

interface ChannelStore {
    fun findAll(): List<ChannelModel>
    fun create(Channel: ChannelModel)
    fun update(Channel: ChannelModel)
    fun delete(Channel: ChannelModel)
}