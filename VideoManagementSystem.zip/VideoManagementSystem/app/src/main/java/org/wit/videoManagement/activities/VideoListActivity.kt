package org.wit.videoManagement.activities

import android.annotation.SuppressLint
import android.app.UiModeManager.MODE_NIGHT_NO
import android.app.UiModeManager.MODE_NIGHT_YES
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import videoManagement.R
import org.wit.videoManagement.adapters.VideoAdapter
import org.wit.videoManagement.adapters.VideoListener
import videoManagement.databinding.ActivityVideoListBinding
import org.wit.videoManagement.main.MainApp
import org.wit.videoManagement.models.VideoModel

class VideoListActivity : AppCompatActivity(), VideoListener/*, MultiplePermissionsListener*/ {

    lateinit var app: MainApp
    private lateinit var binding: ActivityVideoListBinding
    private lateinit var refreshIntentLauncher : ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = title
        setSupportActionBar(binding.toolbar)

        app = application as MainApp

        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager

        val spinner: Spinner = findViewById(R.id.star_spinner)
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            this,
            R.array.stars_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
        }


        loadVideos(spinner.toString())
        registerRefreshCallback()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_add -> {
                val launcherIntent = Intent(this, VideoActivity::class.java)
                refreshIntentLauncher.launch(launcherIntent)
            }
            R.id.channel_add -> {
                val launcherIntent = Intent(this, ChannelActivity::class.java)
                refreshIntentLauncher.launch(launcherIntent)
            }
            R.id.LightMode->{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            R.id.NightMode->{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onVideoClick(Video: VideoModel) {
        val launcherIntent = Intent(this, VideoActivity::class.java)
        launcherIntent.putExtra("Video_edit", Video)
        refreshIntentLauncher.launch(launcherIntent)
    }

    private fun registerRefreshCallback() {
        refreshIntentLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult())
            { loadVideos("all") }
    }

    private fun loadVideos(stars: String) {
        if(stars=="all")
            showVideos(app.Videos.findAll())
        else if(stars=="1-2"){

        }else if(stars == "4+"){

        }else{

        }
    }

    fun showVideos (Videos: List<VideoModel>) {
        binding.recyclerView.adapter = VideoAdapter(Videos, this)
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }



}