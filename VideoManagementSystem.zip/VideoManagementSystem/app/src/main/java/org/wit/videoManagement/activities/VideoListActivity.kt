package org.wit.videoManagement.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import videoManagement.R
import org.wit.videoManagement.adapters.VideoAdapter
import org.wit.videoManagement.adapters.VideoListener
import videoManagement.databinding.ActivityVideoListBinding
import org.wit.videoManagement.main.MainApp
import org.wit.videoManagement.models.VideoModel

class VideoListActivity : AppCompatActivity(), VideoListener/*, MultiplePermissionsListener*/ {

    lateinit var app: MainApp
    private lateinit var binding: ActivityVideoListBinding
    private lateinit var refreshIntentLauncher : ActivityResultLauncher<Intent>
    private lateinit var mapIntentLauncher : ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = title
        setSupportActionBar(binding.toolbar)

        app = application as MainApp

        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager

        loadVideos()
        registerRefreshCallback()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_add -> {
                val launcherIntent = Intent(this, VideoActivity::class.java)
                refreshIntentLauncher.launch(launcherIntent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onVideoClick(Video: VideoModel) {
        val launcherIntent = Intent(this, VideoActivity::class.java)
        launcherIntent.putExtra("Video_edit", Video)
        refreshIntentLauncher.launch(launcherIntent)
    }

    private fun registerRefreshCallback() {
        refreshIntentLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult())
            { loadVideos() }
    }

    private fun loadVideos() {
        showVideos(app.Videos.findAll())
    }

    fun showVideos (Videos: List<VideoModel>) {
        binding.recyclerView.adapter = VideoAdapter(Videos, this)
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }

}