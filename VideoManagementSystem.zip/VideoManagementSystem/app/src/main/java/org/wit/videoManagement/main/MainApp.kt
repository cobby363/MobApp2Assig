package org.wit.videoManagement.main

import android.app.Application
import org.wit.videoManagement.models.ChannelJSONStore
import org.wit.videoManagement.models.ChannelStore
import org.wit.videoManagement.models.VideoJSONStore
import org.wit.videoManagement.models.VideoStore
import timber.log.Timber
import timber.log.Timber.i

class MainApp : Application() {

    lateinit var Videos: VideoStore
    lateinit var Channels: ChannelStore

    override fun onCreate() {
        super.onCreate()
        Timber.plant(Timber.DebugTree())
        Videos = VideoJSONStore(applicationContext)
        Channels = ChannelJSONStore(applicationContext)
        i("Video started")
    }
}