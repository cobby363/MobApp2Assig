package org.wit.videoManagement.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import videoManagement.databinding.CardVideoBinding
import org.wit.videoManagement.models.VideoModel

interface VideoListener {
    fun onVideoClick(Video: VideoModel)
}

class VideoAdapter constructor(
    private var Videos: List<VideoModel>,
    private val listener: VideoListener
) :
        RecyclerView.Adapter<VideoAdapter.MainHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        val binding = CardVideoBinding
                .inflate(LayoutInflater.from(parent.context), parent, false)

        return MainHolder(binding)
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val Video = Videos[holder.adapterPosition]
        holder.bind(Video, listener)
    }

    override fun getItemCount(): Int = Videos.size

    class MainHolder(private val binding: CardVideoBinding) :
            RecyclerView.ViewHolder(binding.root) {

        fun bind(Video: VideoModel, listener: VideoListener) {
            binding.VideoTitle.text = Video.title
            binding.description.text = Video.description
            Picasso.get().load(Video.image).resize(200,200).into(binding.imageIcon)
            binding.root.setOnClickListener { listener.onVideoClick(Video) }
        }
    }
}
